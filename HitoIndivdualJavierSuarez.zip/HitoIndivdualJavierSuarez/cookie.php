<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ver cookie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    
</head>
<body>
<ul>
      <li><a href="comprobarcookie.php">Ver Cookie</a></li>
      <li><a href="insertar.html">Añadir comentarios</a></li>
      <li><a href="comprobarcookie.php">Eliminar/Actualizar entradas</a></li>
      <li style="float:right"><a class="active" href="login.html">Inicio de sesión</a></li>
    </ul>
<h1>Cookie</h1>

<?php
$fecha_actual = date('h:i:s');
$ip=$_SERVER['REMOTE_ADDR'];
session_start();
$_SESSION['token']=session_id();
if(isset($_SESSION['token'])){
    echo('Cookie añadida ');
    echo("<p>La cookie añadida es ".$_SESSION['token']."</p>");
    echo("<p>La ip es ".$ip."</p>");
    echo("<p>inicio de sesion a las ".$fecha_actual."</p>");
}
else{
    echo(' No añadida. Inicie sesión');
}

?>

</body>
</html>


