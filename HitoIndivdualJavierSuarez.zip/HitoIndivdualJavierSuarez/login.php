<?php
    if(isset($_POST['dato'])){
        $correo=$_POST['correo'];
        $password=$_POST['password'];
        $conn=new PDO("mysql:host=localhost;port=3306;dbname=test","root","");
        $consulta="select * from `hitos`";
        $resultado=$conn->query($consulta); 
        while($row=$resultado->fetch()) {
           if($row['correo']==$correo and $row['password']==$password){
           header('location:index.html');
           session_start();
           $_SESSION['token']=session_id();
            break;
           }
           else{
            echo("<p>Incorrecto. Vuelve a intentarlo</p>");
           }
        } 
    }
    ?>